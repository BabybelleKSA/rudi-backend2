
const uploadInput = document.getElementById('upload-input');
const analyzeBtn = document.getElementById('btn-analyze');
const feedbackDiv = document.getElementById('feedback');
let selectedVideoFile = null;

document.getElementById('btn-upload').addEventListener('click', () => {
  uploadInput.click();
});

uploadInput.addEventListener('change', (event) => {
  selectedVideoFile = event.target.files[0];
  feedbackDiv.textContent = `Video ready to analyze: ${selectedVideoFile.name}`;
});

analyzeBtn.addEventListener('click', () => {
  if (!selectedVideoFile) {
    feedbackDiv.textContent = 'Please upload a video first.';
    return;
  }

  const formData = new FormData();
  formData.append('video', selectedVideoFile);

  fetch('https://rudi-backend2-production.up.railway.app/analyze', {
    method: 'POST',
    body: formData
  })
    .then(res => res.json())
    .then(data => {
      feedbackDiv.innerHTML = `
        <strong>Analysis Results:</strong><br>
        Frames analyzed: ${data.frames_analyzed}<br>
        Motion frames: ${data.frames_with_hand_motion}<br>
        Beats detected: ${data.beats_detected}<br>
        Motion activity: ${data.motion_activity_score || 'N/A'}<br>
        Consistency: ${data.consistency_score || 'N/A'}<br>
        <em>${data.feedback}</em>
      `;
    })
    .catch(err => {
      console.error(err);
      feedbackDiv.textContent = 'Error analyzing video.';
    });
});
